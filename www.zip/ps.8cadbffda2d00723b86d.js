onmessage = function(e) {
  eval(e.data);
}