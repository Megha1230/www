(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[326],{

/***/ "jBpv":
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/relationship-officer-details/relationship-officer-details.page.scss ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWxhdGlvbnNoaXAtb2ZmaWNlci1kZXRhaWxzLnBhZ2Uuc2NzcyJ9 */");

/***/ })

}]);
//# sourceMappingURL=326-es2015.js.map