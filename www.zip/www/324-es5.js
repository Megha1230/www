(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[324], {
    /***/
    "GrZt":
    /*!***********************************************************************!*\
      !*** ./src/app/pages/redemption-history/redemption-history.page.scss ***!
      \***********************************************************************/

    /*! exports provided: default */

    /***/
    function GrZt(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWRlbXB0aW9uLWhpc3RvcnkucGFnZS5zY3NzIn0= */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=324-es5.js.map