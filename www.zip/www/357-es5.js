(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[357], {
    /***/
    "ceoR":
    /*!***************************************************************************!*\
      !*** ./src/app/pages/authorized-signatory/authorized-signatory.page.html ***!
      \***************************************************************************/

    /*! no static exports found */

    /***/
    function ceoR(module, exports) {
      throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-view [options]=\"templateViewOptions\">\n|   <ps-complex-segment id=\"Segment\" (complexSegmentButtonClicked)=\"onClickSegment($event)\"\n|     [options]=\"complexSegmentOptions\">");
      /***/
    }
  }]);
})();