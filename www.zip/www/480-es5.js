(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[480], {
    /***/
    "cOqI":
    /*!***********************************************************!*\
      !*** ./src/app/pages/visa-request/visa-request.page.html ***!
      \***********************************************************/

    /*! no static exports found */

    /***/
    function cOqI(module, exports) {
      throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-multi-outlets [id]=\"options.outletName\" [outletOptions]=\"options\" #multiTemplateRef>\n|     <ng-container multiPageData>\n|         <ps-container-panel [options]=\"panelOptions1\">");
      /***/
    }
  }]);
})();