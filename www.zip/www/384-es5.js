(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[384], {
    /***/
    "EhXj":
    /*!***********************************************************!*\
      !*** ./src/app/pages/contact-bank/contact-bank.page.html ***!
      \***********************************************************/

    /*! no static exports found */

    /***/
    function EhXj(module, exports) {
      throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-stepper [options]=\"options\" [id]=\"options.stepperName\">\n|   <ps-form-step *psStep=\"'step1'\" step1 [id]=\"options.namesofSteps[0]\">\n|     <ps-container-panel [options]=\"panelOptions\" id=\"contact_panel\">");
      /***/
    }
  }]);
})();