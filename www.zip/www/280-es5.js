(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[280], {
    /***/
    "uL9s":
    /*!*********************************************************!*\
      !*** ./src/app/pages/cif-opening/cif-opening.page.scss ***!
      \*********************************************************/

    /*! exports provided: default */

    /***/
    function uL9s(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaWYtb3BlbmluZy5wYWdlLnNjc3MifQ== */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=280-es5.js.map