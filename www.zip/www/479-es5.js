(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[479], {
    /***/
    "EM9y":
    /*!*********************************************************************!*\
      !*** ./src/app/pages/ussd-deactivation/ussd-deactivation.page.html ***!
      \*********************************************************************/

    /*! no static exports found */

    /***/
    function EM9y(module, exports) {
      throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-form [options]=\"options\">\n|   <ps-label class=\"text-warning-ussd-dactivation\" [options]=\"ussddeactivationLabelOptions\"></ps-label>\n| ");
      /***/
    }
  }]);
})();