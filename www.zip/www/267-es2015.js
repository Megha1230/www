(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[267],{

/***/ "D8t5":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/break-term-deposit-account/break-term-deposit-account.page.scss ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/* break term deposit account css*/\n.test {\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL2JyZWFrLXRlcm0tZGVwb3NpdC1hY2NvdW50LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxrQ0FBQTtBQUVBO0VBQ0ksa0JBQUE7QUFBSiIsImZpbGUiOiJicmVhay10ZXJtLWRlcG9zaXQtYWNjb3VudC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBicmVhayB0ZXJtIGRlcG9zaXQgYWNjb3VudCBjc3MqL1xyXG5cclxuLnRlc3Qge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59Il19 */");

/***/ })

}]);
//# sourceMappingURL=267-es2015.js.map