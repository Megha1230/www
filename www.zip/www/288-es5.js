(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[288], {
    /***/
    "kzgv":
    /*!*********************************************************************************!*\
      !*** ./src/app/pages/expired-securities-list/expired-securities-list.page.scss ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function kzgv(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJleHBpcmVkLXNlY3VyaXRpZXMtbGlzdC5wYWdlLnNjc3MifQ== */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=288-es5.js.map