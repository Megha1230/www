(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[460],{

/***/ "HC/Y":
/*!*********************************************************!*\
  !*** ./src/app/pages/report-page/report-page.page.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-report #reportTemplate [options]=\"reportTemplateOptions\" id=\"report_page\"></ps-template-report>");

/***/ })

}]);
//# sourceMappingURL=460-es2015.js.map