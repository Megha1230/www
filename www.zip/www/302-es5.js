(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[302], {
    /***/
    "isaJ":
    /*!*******************************************************************************!*\
      !*** ./src/app/pages/loyalty-points-history/loyalty-points-history.page.scss ***!
      \*******************************************************************************/

    /*! exports provided: default */

    /***/
    function isaJ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsb3lhbHR5LXBvaW50cy1oaXN0b3J5LnBhZ2Uuc2NzcyJ9 */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=302-es5.js.map