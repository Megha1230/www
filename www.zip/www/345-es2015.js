(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[345],{

/***/ "BC7/":
/*!*******************************************************************!*\
  !*** ./src/app/pages/account-deletion/account-deletion.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-form [options]=\"options\">\n|   <ps-container-panel [options]=\"panelAccountDeletionOptions\" id=\"pin_panel\">\n| ");

/***/ })

}]);
//# sourceMappingURL=345-es2015.js.map