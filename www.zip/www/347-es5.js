(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[347], {
    /***/
    "Xh0k":
    /*!*****************************************************************!*\
      !*** ./src/app/pages/account-opening/account-opening.page.html ***!
      \*****************************************************************/

    /*! no static exports found */

    /***/
    function Xh0k(module, exports) {
      throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <!-- <ion-content > -->\n| \n| <ps-template-stepper [options]=\"stepperOptions\" [id]=\"stepperOptions.stepperName\">");
      /***/
    }
  }]);
})();