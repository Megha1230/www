(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[289],{

/***/ "3APC":
/*!*****************************************************************!*\
  !*** ./src/app/pages/facilities-list/facilities-list.page.scss ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmYWNpbGl0aWVzLWxpc3QucGFnZS5zY3NzIn0= */");

/***/ })

}]);
//# sourceMappingURL=289-es2015.js.map