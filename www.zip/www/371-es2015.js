(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[371],{

/***/ "FiW4":
/*!*******************************************************!*\
  !*** ./src/app/pages/cards-list/cards-list.page.html ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-view [options]=\"templateViewOptions\">\n|     <ps-complex-segment id=\"cardsSegment\" (complexSegmentButtonClicked)=\"onClickSegment($event)\"\n|         [options]=\"complexSegmentOptions\">");

/***/ })

}]);
//# sourceMappingURL=371-es2015.js.map