(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-ipn-money-transfer-ipn-money-transfer-module"],{

/***/ "4Ywu":
/*!********************************************************************************************************************************************************!*\
  !*** ./src/app/commonBussinessSRC/psComponents/ps-select-dropdown/ps-dropdown-lov/ps-dropdown-psp-handler/ps-dropdown-psp-handler.component.module.ts ***!
  \********************************************************************************************************************************************************/
/*! exports provided: PsDropdownPspHandlerComponentModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PsDropdownPspHandlerComponentModule", function() { return PsDropdownPspHandlerComponentModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_commonSRC_psComponents_ps_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/commonSRC/psComponents/ps-components.module */ "dqXS");
/* harmony import */ var src_app_commonSRC_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/commonSRC/shared.module */ "rlZq");
/* harmony import */ var _ps_dropdown_psp_handler_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ps-dropdown-psp-handler.component */ "UjdT");





let PsDropdownPspHandlerComponentModule = class PsDropdownPspHandlerComponentModule {
};
PsDropdownPspHandlerComponentModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_ps_dropdown_psp_handler_component__WEBPACK_IMPORTED_MODULE_4__["PsDropdownPspHandlerComponent"]],
        imports: [
            src_app_commonSRC_shared_module__WEBPACK_IMPORTED_MODULE_3__["SharedModule"],
            src_app_commonSRC_psComponents_ps_components_module__WEBPACK_IMPORTED_MODULE_2__["PsComponentsModule"]
        ],
        exports: [_ps_dropdown_psp_handler_component__WEBPACK_IMPORTED_MODULE_4__["PsDropdownPspHandlerComponent"]],
        entryComponents: [_ps_dropdown_psp_handler_component__WEBPACK_IMPORTED_MODULE_4__["PsDropdownPspHandlerComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], PsDropdownPspHandlerComponentModule);



/***/ }),

/***/ "4m3D":
/*!********************************************************************************************************************************************************!*\
  !*** ./src/app/commonBussinessSRC/psComponents/ps-complex-components/ps-complex-instant-pay-address/ps-complex-instant-pay-adress.component.module.ts ***!
  \********************************************************************************************************************************************************/
/*! exports provided: PsComplexInstantPayAddressComponentModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PsComplexInstantPayAddressComponentModule", function() { return PsComplexInstantPayAddressComponentModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_commonSRC_psComponents_ps_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/commonSRC/psComponents/ps-components.module */ "dqXS");
/* harmony import */ var src_app_commonSRC_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/commonSRC/shared.module */ "rlZq");
/* harmony import */ var _ps_keyin_input_ps_input_varchar_ps_input_varchar_component_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../ps-keyin-input/ps-input-varchar/ps-input-varchar.component.module */ "oZQX");
/* harmony import */ var _ps_select_dropdown_ps_dropdown_lov_ps_dropdown_psp_handler_ps_dropdown_psp_handler_component_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../ps-select-dropdown/ps-dropdown-lov/ps-dropdown-psp-handler/ps-dropdown-psp-handler.component.module */ "4Ywu");
/* harmony import */ var _ps_complex_instant_pay_address_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ps-complex-instant-pay-address.component */ "t4PS");







let PsComplexInstantPayAddressComponentModule = class PsComplexInstantPayAddressComponentModule {
};
PsComplexInstantPayAddressComponentModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [
            _ps_complex_instant_pay_address_component__WEBPACK_IMPORTED_MODULE_6__["PsComplexInstantPayAddressComponent"]
        ],
        imports: [
            src_app_commonSRC_shared_module__WEBPACK_IMPORTED_MODULE_3__["SharedModule"],
            src_app_commonSRC_psComponents_ps_components_module__WEBPACK_IMPORTED_MODULE_2__["PsComponentsModule"],
            _ps_keyin_input_ps_input_varchar_ps_input_varchar_component_module__WEBPACK_IMPORTED_MODULE_4__["PsInputVarcharComponentModule"],
            _ps_select_dropdown_ps_dropdown_lov_ps_dropdown_psp_handler_ps_dropdown_psp_handler_component_module__WEBPACK_IMPORTED_MODULE_5__["PsDropdownPspHandlerComponentModule"],
        ],
        exports: [
            _ps_complex_instant_pay_address_component__WEBPACK_IMPORTED_MODULE_6__["PsComplexInstantPayAddressComponent"]
        ],
        entryComponents: [
            _ps_complex_instant_pay_address_component__WEBPACK_IMPORTED_MODULE_6__["PsComplexInstantPayAddressComponent"]
        ],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], PsComplexInstantPayAddressComponentModule);



/***/ }),

/***/ "6Ozt":
/*!**********************************************************************************!*\
  !*** ./src/app/commonBussinessSRC/psComponents/ps-banks/ps-banks.component.scss ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcy1iYW5rcy5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "6aI7":
/*!*******************************************************************************************************************************************************************!*\
  !*** ./src/app/commonBussinessSRC/psComponents/ps-select-dropdown/ps-dropdown-lov/ps-lov-beneficiary-account-type/ps-lov-beneficiary-account-type.component.scss ***!
  \*******************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcy1sb3YtYmVuZWZpY2lhcnktYWNjb3VudC10eXBlLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "D2J3":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/commonBussinessSRC/psComponents/ps-banks/ps-banks.component.html ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ps-category-sub-category [options]=\"categoriesOptions\" (onPsChange)=\"onBankChanged($event)\"></ps-category-sub-category>");

/***/ }),

/***/ "I5TQ":
/*!*********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/commonBussinessSRC/psComponents/ps-select-dropdown/ps-dropdown-lov/ps-lov-beneficiary-account-type/ps-lov-beneficiary-account-type.component.html ***!
  \*********************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ps-dropdown-lov [id]=\"id\" [options]=\"defaultSelectOptions\" (onPsChange)=\"onChangeLov($event)\"></ps-dropdown-lov>");

/***/ }),

/***/ "OeWz":
/*!******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/commonBussinessSRC/psComponents/ps-complex-components/ps-complex-instant-pay-address/ps-complex-instant-pay-address.component.html ***!
  \******************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ps-container-complex class=\"ps-complex-instant-pay-address-container\">\n  <ps-input-varchar id=\"instantPayAddress\" [options]=\"options.addressOptions\" (onPsChange)=\"addressChanged($event)\"\n    class=\"ps-input-varchar-wrapper\"></ps-input-varchar>\n  <ps-dropdown-psp-handler id=\"pspHandler\" [options]=\"options.pspHandlerOptions\" (onPsChange)=\"handlerChanged($event)\"\n    class=\"ps-dropdown-psp-handler-wrapper\"></ps-dropdown-psp-handler>\n</ps-container-complex>");

/***/ }),

/***/ "SmT2":
/*!****************************************************************************************************************************************************!*\
  !*** ./src/app/commonBussinessSRC/psComponents/ps-complex-components/ps-complex-instant-pay-address/ps-complex-instant-pay-address.component.scss ***!
  \****************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcy1jb21wbGV4LWluc3RhbnQtcGF5LWFkZHJlc3MuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "UjdT":
/*!*************************************************************************************************************************************************!*\
  !*** ./src/app/commonBussinessSRC/psComponents/ps-select-dropdown/ps-dropdown-lov/ps-dropdown-psp-handler/ps-dropdown-psp-handler.component.ts ***!
  \*************************************************************************************************************************************************/
/*! exports provided: PsDropdownPspHandlerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PsDropdownPspHandlerComponent", function() { return PsDropdownPspHandlerComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_ps_dropdown_psp_handler_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./ps-dropdown-psp-handler.component.html */ "tvla");
/* harmony import */ var _ps_dropdown_psp_handler_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ps-dropdown-psp-handler.component.scss */ "qclh");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_commonBussinessSRC_psServices_omni_common_omni_pull_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/commonBussinessSRC/psServices/omni-common/omni-pull.service */ "ZyuK");
/* harmony import */ var src_app_commonSRC_psComponents_ps_base_ps_base_field_ps_field_select_ps_select_dropdown_ps_select_dropdown_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/commonSRC/psComponents/ps-base/ps-base-field/ps-field-select/ps-select-dropdown/ps-select-dropdown.component */ "iOQE");
/* harmony import */ var src_app_commonSRC_psServices_logger_logger_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/commonSRC/psServices/logger/logger.service */ "DFXC");
/* harmony import */ var src_app_commonSRC_psServices_ps_common_ps_common_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/commonSRC/psServices/ps-common/ps-common.service */ "Q0Ba");








let PsDropdownPspHandlerComponent = class PsDropdownPspHandlerComponent extends src_app_commonSRC_psComponents_ps_base_ps_base_field_ps_field_select_ps_select_dropdown_ps_select_dropdown_component__WEBPACK_IMPORTED_MODULE_5__["PsSelectDropdownComponent"] {
    constructor(commonProv, loggerP, omniPull) {
        super(commonProv, loggerP);
        this.omniPull = omniPull;
        this.defaultSelectOptions = {};
    }
    ngOnInit() {
        this.commonProv.copyObject(this.defaultSelectOptions, this.options, false);
        this.loadPspHandlers();
    }
    //to be updated by right properties when service is done
    loadPspHandlers() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const handlersRequest = {};
            const result = yield this.omniPull.returnPspHandlers(handlersRequest).catch(error => {
                this.logger.error('Error: While fetching handlers in PsDropdownPspHandlerComponent :', error);
            });
            this.defaultSelectOptions.listOfOptions = [];
            if (result && result.gridModel) {
                for (const iterator of result.gridModel) {
                    const eachHandler = {
                        itemValue: iterator.IPN_PSPS_ID.toString(),
                        description: '@' + iterator.PSP_HANDLES,
                        selectedObj: iterator
                    };
                    this.defaultSelectOptions.listOfOptions.push(eachHandler);
                }
            }
        });
    }
    onHandlerChange(values) {
        this.onPsChange.emit(values);
    }
};
PsDropdownPspHandlerComponent.ctorParameters = () => [
    { type: src_app_commonSRC_psServices_ps_common_ps_common_service__WEBPACK_IMPORTED_MODULE_7__["PsCommonService"] },
    { type: src_app_commonSRC_psServices_logger_logger_service__WEBPACK_IMPORTED_MODULE_6__["LoggerService"] },
    { type: src_app_commonBussinessSRC_psServices_omni_common_omni_pull_service__WEBPACK_IMPORTED_MODULE_4__["OmniPullService"] }
];
PsDropdownPspHandlerComponent.propDecorators = {
    options: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
PsDropdownPspHandlerComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'ps-dropdown-psp-handler',
        template: _raw_loader_ps_dropdown_psp_handler_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ps_dropdown_psp_handler_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [src_app_commonSRC_psServices_ps_common_ps_common_service__WEBPACK_IMPORTED_MODULE_7__["PsCommonService"], src_app_commonSRC_psServices_logger_logger_service__WEBPACK_IMPORTED_MODULE_6__["LoggerService"], src_app_commonBussinessSRC_psServices_omni_common_omni_pull_service__WEBPACK_IMPORTED_MODULE_4__["OmniPullService"]])
], PsDropdownPspHandlerComponent);



/***/ }),

/***/ "UqcP":
/*!************************************************************************************************************************************************************************!*\
  !*** ./src/app/commonBussinessSRC/psComponents/ps-select-dropdown/ps-dropdown-lov/ps-lov-beneficiary-account-type/ps-lov-beneficiary-account-type.component.module.ts ***!
  \************************************************************************************************************************************************************************/
/*! exports provided: PsLovBeneficiaryAccountTypeComponentModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PsLovBeneficiaryAccountTypeComponentModule", function() { return PsLovBeneficiaryAccountTypeComponentModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_commonSRC_psComponents_ps_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/commonSRC/psComponents/ps-components.module */ "dqXS");
/* harmony import */ var src_app_commonSRC_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/commonSRC/shared.module */ "rlZq");
/* harmony import */ var _ps_dropdown_lov_component_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../ps-dropdown-lov.component.module */ "LhaX");
/* harmony import */ var _ps_lov_beneficiary_account_type_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ps-lov-beneficiary-account-type.component */ "xvo3");






let PsLovBeneficiaryAccountTypeComponentModule = class PsLovBeneficiaryAccountTypeComponentModule {
};
PsLovBeneficiaryAccountTypeComponentModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_ps_lov_beneficiary_account_type_component__WEBPACK_IMPORTED_MODULE_5__["PsLovBeneficiaryAccountTypeComponent"]],
        imports: [
            src_app_commonSRC_shared_module__WEBPACK_IMPORTED_MODULE_3__["SharedModule"],
            src_app_commonSRC_psComponents_ps_components_module__WEBPACK_IMPORTED_MODULE_2__["PsComponentsModule"],
            _ps_dropdown_lov_component_module__WEBPACK_IMPORTED_MODULE_4__["PsDropdownLovComponentModule"]
        ],
        exports: [_ps_lov_beneficiary_account_type_component__WEBPACK_IMPORTED_MODULE_5__["PsLovBeneficiaryAccountTypeComponent"]],
        entryComponents: [_ps_lov_beneficiary_account_type_component__WEBPACK_IMPORTED_MODULE_5__["PsLovBeneficiaryAccountTypeComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], PsLovBeneficiaryAccountTypeComponentModule);



/***/ }),

/***/ "mpNL":
/*!********************************************************************************!*\
  !*** ./src/app/commonBussinessSRC/psComponents/ps-banks/ps-banks.component.ts ***!
  \********************************************************************************/
/*! exports provided: PsBanksComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PsBanksComponent", function() { return PsBanksComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_ps_banks_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./ps-banks.component.html */ "D2J3");
/* harmony import */ var _ps_banks_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ps-banks.component.scss */ "6Ozt");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_commonBussinessSRC_psServices_models_ps_common_bussiness_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/commonBussinessSRC/psServices/models/ps-common-bussiness-constant */ "V0Fi");
/* harmony import */ var src_app_commonSRC_psComponents_ps_base_ps_base_field_ps_base_field_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/commonSRC/psComponents/ps-base/ps-base-field/ps-base-field.component */ "ZF3V");
/* harmony import */ var src_app_commonSRC_psServices_logger_logger_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/commonSRC/psServices/logger/logger.service */ "DFXC");
/* harmony import */ var src_app_commonSRC_psServices_ps_common_ps_common_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/commonSRC/psServices/ps-common/ps-common.service */ "Q0Ba");








let PsBanksComponent = class PsBanksComponent extends src_app_commonSRC_psComponents_ps_base_ps_base_field_ps_base_field_component__WEBPACK_IMPORTED_MODULE_5__["PsBaseFieldComponent"] {
    constructor(commonService, logger) {
        super(commonService, logger);
        this.options = {};
        this.categoriesOptions = {};
    }
    ngOnInit() {
        this.categoriesOptions = {
            type: src_app_commonBussinessSRC_psServices_models_ps_common_bussiness_constant__WEBPACK_IMPORTED_MODULE_4__["CommonBussinessConstant"].CATEGORY_BANK,
            defaultLoad: true,
            category: {
                labelKey: this.options.categoryLabelKey,
                placeHolder: this.options.categoryPlaceholderKey,
                fcName: this.options.categoryFcName,
                group: this.options.group
            },
            subCategory: {
                labelKey: this.options.subCategoryLabelKey,
                placeHolder: this.options.subCategoryPlaceholderKey,
                fcName: this.options.subCategoryFcName,
                group: this.options.group
            },
            requestObject: this.options.requestObject
        };
    }
    onBankChanged(event) {
        this.onPsChange.emit(event);
    }
};
PsBanksComponent.ctorParameters = () => [
    { type: src_app_commonSRC_psServices_ps_common_ps_common_service__WEBPACK_IMPORTED_MODULE_7__["PsCommonService"] },
    { type: src_app_commonSRC_psServices_logger_logger_service__WEBPACK_IMPORTED_MODULE_6__["LoggerService"] }
];
PsBanksComponent.propDecorators = {
    options: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
PsBanksComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'ps-banks',
        template: _raw_loader_ps_banks_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ps_banks_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [src_app_commonSRC_psServices_ps_common_ps_common_service__WEBPACK_IMPORTED_MODULE_7__["PsCommonService"],
        src_app_commonSRC_psServices_logger_logger_service__WEBPACK_IMPORTED_MODULE_6__["LoggerService"]])
], PsBanksComponent);



/***/ }),

/***/ "qclh":
/*!***************************************************************************************************************************************************!*\
  !*** ./src/app/commonBussinessSRC/psComponents/ps-select-dropdown/ps-dropdown-lov/ps-dropdown-psp-handler/ps-dropdown-psp-handler.component.scss ***!
  \***************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcy1kcm9wZG93bi1wc3AtaGFuZGxlci5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "sUWf":
/*!***************************************************************************************!*\
  !*** ./src/app/commonBussinessSRC/psComponents/ps-banks/ps-banks.component.module.ts ***!
  \***************************************************************************************/
/*! exports provided: PsBanksComponentModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PsBanksComponentModule", function() { return PsBanksComponentModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_commonSRC_psComponents_ps_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/commonSRC/psComponents/ps-components.module */ "dqXS");
/* harmony import */ var src_app_commonSRC_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/commonSRC/shared.module */ "rlZq");
/* harmony import */ var _ps_banks_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ps-banks.component */ "mpNL");





let PsBanksComponentModule = class PsBanksComponentModule {
};
PsBanksComponentModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [
            _ps_banks_component__WEBPACK_IMPORTED_MODULE_4__["PsBanksComponent"]
        ],
        imports: [
            src_app_commonSRC_shared_module__WEBPACK_IMPORTED_MODULE_3__["SharedModule"],
            src_app_commonSRC_psComponents_ps_components_module__WEBPACK_IMPORTED_MODULE_2__["PsComponentsModule"]
        ],
        exports: [
            _ps_banks_component__WEBPACK_IMPORTED_MODULE_4__["PsBanksComponent"]
        ],
        entryComponents: [
            _ps_banks_component__WEBPACK_IMPORTED_MODULE_4__["PsBanksComponent"]
        ],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], PsBanksComponentModule);



/***/ }),

/***/ "t4PS":
/*!**************************************************************************************************************************************************!*\
  !*** ./src/app/commonBussinessSRC/psComponents/ps-complex-components/ps-complex-instant-pay-address/ps-complex-instant-pay-address.component.ts ***!
  \**************************************************************************************************************************************************/
/*! exports provided: PsComplexInstantPayAddressComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PsComplexInstantPayAddressComponent", function() { return PsComplexInstantPayAddressComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_ps_complex_instant_pay_address_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./ps-complex-instant-pay-address.component.html */ "OeWz");
/* harmony import */ var _ps_complex_instant_pay_address_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ps-complex-instant-pay-address.component.scss */ "SmT2");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_commonSRC_psComponents_ps_base_ps_base_field_ps_base_field_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/commonSRC/psComponents/ps-base/ps-base-field/ps-base-field.component */ "ZF3V");
/* harmony import */ var src_app_commonSRC_psServices_logger_logger_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/commonSRC/psServices/logger/logger.service */ "DFXC");
/* harmony import */ var src_app_commonSRC_psServices_ps_common_ps_common_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/commonSRC/psServices/ps-common/ps-common.service */ "Q0Ba");







let PsComplexInstantPayAddressComponent = class PsComplexInstantPayAddressComponent extends src_app_commonSRC_psComponents_ps_base_ps_base_field_ps_base_field_component__WEBPACK_IMPORTED_MODULE_4__["PsBaseFieldComponent"] {
    constructor(commonProv, loggerP) {
        super(commonProv, loggerP);
        this.commonProv = commonProv;
        this.loggerP = loggerP;
        this.onHandlerChange = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.onAddressChange = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
    }
    ngOnInit() {
        super.init();
    }
    handlerChanged(event) {
        this.onHandlerChange.emit(event);
    }
    addressChanged(event) {
        this.onAddressChange.emit(event);
    }
};
PsComplexInstantPayAddressComponent.ctorParameters = () => [
    { type: src_app_commonSRC_psServices_ps_common_ps_common_service__WEBPACK_IMPORTED_MODULE_6__["PsCommonService"] },
    { type: src_app_commonSRC_psServices_logger_logger_service__WEBPACK_IMPORTED_MODULE_5__["LoggerService"] }
];
PsComplexInstantPayAddressComponent.propDecorators = {
    options: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    onHandlerChange: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }],
    onAddressChange: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }]
};
PsComplexInstantPayAddressComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'ps-complex-instant-pay-address',
        template: _raw_loader_ps_complex_instant_pay_address_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ps_complex_instant_pay_address_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [src_app_commonSRC_psServices_ps_common_ps_common_service__WEBPACK_IMPORTED_MODULE_6__["PsCommonService"], src_app_commonSRC_psServices_logger_logger_service__WEBPACK_IMPORTED_MODULE_5__["LoggerService"]])
], PsComplexInstantPayAddressComponent);



/***/ }),

/***/ "tvla":
/*!*****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/commonBussinessSRC/psComponents/ps-select-dropdown/ps-dropdown-lov/ps-dropdown-psp-handler/ps-dropdown-psp-handler.component.html ***!
  \*****************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ps-select-dropdown [id]=\"id\" [options]=\"defaultSelectOptions\"\n  (onPsChange)=\"onHandlerChange($event)\"></ps-select-dropdown>");

/***/ }),

/***/ "u/jk":
/*!***********************************************************************!*\
  !*** ./src/app/pages/ipn-money-transfer/ipn-money-transfer.module.ts ***!
  \***********************************************************************/
/*! exports provided: IPNMoneyTransferPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IPNMoneyTransferPageModule", function() { return IPNMoneyTransferPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var src_app_commonBussinessSRC_psComponents_ps_banks_ps_banks_component_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/commonBussinessSRC/psComponents/ps-banks/ps-banks.component.module */ "sUWf");
/* harmony import */ var src_app_commonBussinessSRC_psComponents_ps_complex_components_ps_complex_amount_ps_complex_amount_component_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/commonBussinessSRC/psComponents/ps-complex-components/ps-complex-amount/ps-complex-amount.component.module */ "Uxj/");
/* harmony import */ var src_app_commonBussinessSRC_psComponents_ps_complex_components_ps_complex_instant_pay_address_ps_complex_instant_pay_adress_component_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/commonBussinessSRC/psComponents/ps-complex-components/ps-complex-instant-pay-address/ps-complex-instant-pay-adress.component.module */ "4m3D");
/* harmony import */ var src_app_commonBussinessSRC_psComponents_ps_field_entity_ps_entity_phone_number_ps_entity_phone_number_component_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/commonBussinessSRC/psComponents/ps-field-entity/ps-entity-phone-number/ps-entity-phone-number.component.module */ "Hy46");
/* harmony import */ var src_app_commonBussinessSRC_psComponents_ps_keyin_input_ps_input_account_number_ps_input_account_number_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/commonBussinessSRC/psComponents/ps-keyin-input/ps-input-account-number/ps-input-account-number.module */ "iNXY");
/* harmony import */ var src_app_commonBussinessSRC_psComponents_ps_keyin_input_ps_input_card_number_ps_input_card_number_component_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/commonBussinessSRC/psComponents/ps-keyin-input/ps-input-card-number/ps-input-card-number.component.module */ "gByX");
/* harmony import */ var src_app_commonBussinessSRC_psComponents_ps_keyin_input_ps_input_varchar_ps_input_varchar_component_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/commonBussinessSRC/psComponents/ps-keyin-input/ps-input-varchar/ps-input-varchar.component.module */ "oZQX");
/* harmony import */ var src_app_commonBussinessSRC_psComponents_ps_lookup_ps_lookup_own_accounts_ps_lookup_own_accounts_component_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/commonBussinessSRC/psComponents/ps-lookup/ps-lookup-own-accounts/ps-lookup-own-accounts.component.module */ "xB6I");
/* harmony import */ var src_app_commonBussinessSRC_psComponents_ps_select_dropdown_ps_dropdown_lov_ps_lov_beneficiary_account_type_ps_lov_beneficiary_account_type_component_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/commonBussinessSRC/psComponents/ps-select-dropdown/ps-dropdown-lov/ps-lov-beneficiary-account-type/ps-lov-beneficiary-account-type.component.module */ "UqcP");
/* harmony import */ var src_app_commonSRC_psComponents_ps_components_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/commonSRC/psComponents/ps-components.module */ "dqXS");
/* harmony import */ var src_app_commonSRC_psTemplates_ps_template_stepper_ps_template_stepper_template_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/commonSRC/psTemplates/ps-template-stepper/ps-template-stepper.template.module */ "fM+N");
/* harmony import */ var src_app_commonSRC_shared_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/commonSRC/shared.module */ "rlZq");
/* harmony import */ var _ipn_money_transfer_page__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./ipn-money-transfer.page */ "J2PC");
















const routes = [
    {
        path: '',
        component: _ipn_money_transfer_page__WEBPACK_IMPORTED_MODULE_15__["IPNMoneyTransferPage"]
    }
];
let IPNMoneyTransferPageModule = class IPNMoneyTransferPageModule {
};
IPNMoneyTransferPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            src_app_commonSRC_shared_module__WEBPACK_IMPORTED_MODULE_14__["SharedModule"],
            src_app_commonSRC_psTemplates_ps_template_stepper_ps_template_stepper_template_module__WEBPACK_IMPORTED_MODULE_13__["PsTemplateStepperModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes),
            src_app_commonSRC_psComponents_ps_components_module__WEBPACK_IMPORTED_MODULE_12__["PsComponentsModule"],
            src_app_commonBussinessSRC_psComponents_ps_lookup_ps_lookup_own_accounts_ps_lookup_own_accounts_component_module__WEBPACK_IMPORTED_MODULE_10__["PsLookupOwnAccountComponentModule"],
            src_app_commonBussinessSRC_psComponents_ps_field_entity_ps_entity_phone_number_ps_entity_phone_number_component_module__WEBPACK_IMPORTED_MODULE_6__["PsEntityPhoneNumberComponentModule"],
            src_app_commonBussinessSRC_psComponents_ps_keyin_input_ps_input_varchar_ps_input_varchar_component_module__WEBPACK_IMPORTED_MODULE_9__["PsInputVarcharComponentModule"],
            src_app_commonBussinessSRC_psComponents_ps_complex_components_ps_complex_instant_pay_address_ps_complex_instant_pay_adress_component_module__WEBPACK_IMPORTED_MODULE_5__["PsComplexInstantPayAddressComponentModule"],
            src_app_commonBussinessSRC_psComponents_ps_keyin_input_ps_input_account_number_ps_input_account_number_module__WEBPACK_IMPORTED_MODULE_7__["PsInputAccountNumberComponentModule"],
            src_app_commonBussinessSRC_psComponents_ps_keyin_input_ps_input_card_number_ps_input_card_number_component_module__WEBPACK_IMPORTED_MODULE_8__["PsInputCardNumberComponentModule"],
            src_app_commonBussinessSRC_psComponents_ps_banks_ps_banks_component_module__WEBPACK_IMPORTED_MODULE_3__["PsBanksComponentModule"],
            src_app_commonBussinessSRC_psComponents_ps_complex_components_ps_complex_amount_ps_complex_amount_component_module__WEBPACK_IMPORTED_MODULE_4__["PsComplexAmountComponentModule"],
            src_app_commonBussinessSRC_psComponents_ps_select_dropdown_ps_dropdown_lov_ps_lov_beneficiary_account_type_ps_lov_beneficiary_account_type_component_module__WEBPACK_IMPORTED_MODULE_11__["PsLovBeneficiaryAccountTypeComponentModule"],
        ],
        declarations: [_ipn_money_transfer_page__WEBPACK_IMPORTED_MODULE_15__["IPNMoneyTransferPage"]]
    })
], IPNMoneyTransferPageModule);



/***/ }),

/***/ "xvo3":
/*!*****************************************************************************************************************************************************************!*\
  !*** ./src/app/commonBussinessSRC/psComponents/ps-select-dropdown/ps-dropdown-lov/ps-lov-beneficiary-account-type/ps-lov-beneficiary-account-type.component.ts ***!
  \*****************************************************************************************************************************************************************/
/*! exports provided: PsLovBeneficiaryAccountTypeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PsLovBeneficiaryAccountTypeComponent", function() { return PsLovBeneficiaryAccountTypeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_ps_lov_beneficiary_account_type_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./ps-lov-beneficiary-account-type.component.html */ "I5TQ");
/* harmony import */ var _ps_lov_beneficiary_account_type_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ps-lov-beneficiary-account-type.component.scss */ "6aI7");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_app_commonBussinessSRC_psServices_models_ps_common_bussiness_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/commonBussinessSRC/psServices/models/ps-common-bussiness-constant */ "V0Fi");
/* harmony import */ var src_app_commonBussinessSRC_psServices_models_ps_commonBusiness_settings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/commonBussinessSRC/psServices/models/ps-commonBusiness.settings */ "fOh1");
/* harmony import */ var src_app_commonSRC_psServices_logger_logger_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/commonSRC/psServices/logger/logger.service */ "DFXC");
/* harmony import */ var src_app_commonSRC_psServices_ps_common_ps_common_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/commonSRC/psServices/ps-common/ps-common.service */ "Q0Ba");
/* harmony import */ var _ps_dropdown_lov_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../ps-dropdown-lov.component */ "41l2");









let PsLovBeneficiaryAccountTypeComponent = class PsLovBeneficiaryAccountTypeComponent extends _ps_dropdown_lov_component__WEBPACK_IMPORTED_MODULE_8__["PsDropdownLovComponent"] {
    constructor(commonProvService, logger) {
        super(commonProvService, logger);
        this.defaultSelectOptions = {
            iconLocation: src_app_commonBussinessSRC_psServices_models_ps_commonBusiness_settings__WEBPACK_IMPORTED_MODULE_5__["PsCommonBusinessSettings"].ICON_LOCATION_GENERAL,
            iconExtension: src_app_commonBussinessSRC_psServices_models_ps_commonBusiness_settings__WEBPACK_IMPORTED_MODULE_5__["PsCommonBusinessSettings"].IMG_GENDER_EXTENSION,
            lovTypeId: src_app_commonBussinessSRC_psServices_models_ps_common_bussiness_constant__WEBPACK_IMPORTED_MODULE_4__["CommonBussinessConstant"].LOV_TYPE_ID_BENEFICIARY_ACCOUNT_TYPE
        };
    }
    ngOnInit() {
        this.commonProv.copyObject(this.defaultSelectOptions, this.options, false);
        this.defaultSelectOptions.labelKey = this.commonProv.translate('beneficiary_account_type_key');
        this.defaultSelectOptions.placeHolder = this.commonProv.translate('select_beneficiary_account_type_key');
    }
    onChangeLov(values) {
        this.onPsChange.emit(values);
    }
};
PsLovBeneficiaryAccountTypeComponent.ctorParameters = () => [
    { type: src_app_commonSRC_psServices_ps_common_ps_common_service__WEBPACK_IMPORTED_MODULE_7__["PsCommonService"] },
    { type: src_app_commonSRC_psServices_logger_logger_service__WEBPACK_IMPORTED_MODULE_6__["LoggerService"] }
];
PsLovBeneficiaryAccountTypeComponent.propDecorators = {
    options: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
PsLovBeneficiaryAccountTypeComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'ps-lov-beneficiary-account-type',
        template: _raw_loader_ps_lov_beneficiary_account_type_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ps_lov_beneficiary_account_type_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [src_app_commonSRC_psServices_ps_common_ps_common_service__WEBPACK_IMPORTED_MODULE_7__["PsCommonService"], src_app_commonSRC_psServices_logger_logger_service__WEBPACK_IMPORTED_MODULE_6__["LoggerService"]])
], PsLovBeneficiaryAccountTypeComponent);



/***/ })

}]);
//# sourceMappingURL=pages-ipn-money-transfer-ipn-money-transfer-module-es2015.js.map