(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[318], {
    /***/
    "sVr5":
    /*!***************************************************************************!*\
      !*** ./src/app/pages/personalize-my-limit/personalize-my-limit.page.scss ***!
      \***************************************************************************/

    /*! exports provided: default */

    /***/
    function sVr5(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwZXJzb25hbGl6ZS1teS1saW1pdC5wYWdlLnNjc3MifQ== */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=318-es5.js.map