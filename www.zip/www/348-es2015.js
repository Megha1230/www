(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[348],{

/***/ "7o0L":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/account-statement-list/account-statement-list.page.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-view [options]=\"templateViewOptions\">\n|   <ps-complex-report-filter-criteria (onPsChange)=\"filterCriteria($event)\" [options]=\"reportFilterOptions\"\n|     [id]=\"'filter_criteria'\">");

/***/ })

}]);
//# sourceMappingURL=348-es2015.js.map