(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[410], {
    /***/
    "kgTt":
    /*!***************************************************************************!*\
      !*** ./src/app/pages/internal-beneficiary/internal-beneficiary.page.html ***!
      \***************************************************************************/

    /*! no static exports found */

    /***/
    function kgTt(module, exports) {
      throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <!-- Author: GRadwan 16Jan2020 -->\n| <ps-template-stepper [options]=\"stepperOptions\" [id]=\"stepperOptions.stepperName\">\n| ");
      /***/
    }
  }]);
})();