(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[363],{

/***/ "oE2C":
/*!*******************************************************************!*\
  !*** ./src/app/pages/bpm-dynamic-page/bpm-dynamic-page.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-bpm-flow [options]=\"bpmOptions\" *ngIf=\"bpmOptions.bpmTemplate && bpmOptions.group\" [id]=\"id\">\n| </ps-template-bpm-flow>");

/***/ })

}]);
//# sourceMappingURL=363-es2015.js.map