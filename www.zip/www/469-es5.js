(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[469], {
    /***/
    "Q8BF":
    /*!*************************************************************************************!*\
      !*** ./src/app/pages/sweeping-and-pooling-list/sweeping-and-pooling-list.page.html ***!
      \*************************************************************************************/

    /*! no static exports found */

    /***/
    function Q8BF(module, exports) {
      throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-view [options]=\"templateViewOptions\">\n|   <ps-sweeping-and-pooling-list [options]=\"sweepingPoolingOptions\"  *ngIf=\"sweepingPoolingOptions?.listOfOptions?.length>0\" (reloadFct)=\"reloadList()\"></ps-sweeping-and-pooling-list>\n|   <ps-label [options]=\"noSweepingAndPolingOptions\" *ngIf=\"noSweepingPoolingRecords\" ></ps-label>");
      /***/
    }
  }]);
})();