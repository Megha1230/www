(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[330], {
    /***/
    "Aot4":
    /*!*************************************************************************!*\
      !*** ./src/app/pages/saved-drafts-report/saved-drafts-report.page.scss ***!
      \*************************************************************************/

    /*! exports provided: default */

    /***/
    function Aot4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzYXZlZC1kcmFmdHMtcmVwb3J0LnBhZ2Uuc2NzcyJ9 */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=330-es5.js.map