(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[310], {
    /***/
    "bZnp":
    /*!*************************************************************************!*\
      !*** ./src/app/pages/online-registration/online-registration.page.scss ***!
      \*************************************************************************/

    /*! exports provided: default */

    /***/
    function bZnp(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJvbmxpbmUtcmVnaXN0cmF0aW9uLnBhZ2Uuc2NzcyJ9 */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=310-es5.js.map