(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[263], {
    /***/
    "Isfx":
    /*!*****************************************************!*\
      !*** ./src/app/pages/add-owner/add-owner.page.scss ***!
      \*****************************************************/

    /*! exports provided: default */

    /***/
    function Isfx(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhZGQtb3duZXIucGFnZS5zY3NzIn0= */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=263-es5.js.map