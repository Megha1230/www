(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[424],{

/***/ "Y1WY":
/*!***********************************************************!*\
  !*** ./src/app/pages/multi-outlet/multi-outlet.page.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-multi-outlets [id]=\"options.outletName\" [outletOptions]=\"options\">\n| </ps-template-multi-outlets>");

/***/ })

}]);
//# sourceMappingURL=424-es2015.js.map