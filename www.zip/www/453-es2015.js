(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[453],{

/***/ "nQHc":
/*!*****************************************************************!*\
  !*** ./src/app/pages/qibla-direction/qibla-direction.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-view [options]=\"templateViewOptions\">\n|   <ps-complex-landmark-compass [landmark-location]=\"qiblaLocation\" [options]=\"qiblaDirectionOptions\">\n|   </ps-complex-landmark-compass>");

/***/ })

}]);
//# sourceMappingURL=453-es2015.js.map