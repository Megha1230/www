(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[279],{

/***/ "yqP9":
/*!*****************************************************************!*\
  !*** ./src/app/pages/cif-list-report/cif-list-report.page.scss ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaWYtbGlzdC1yZXBvcnQucGFnZS5zY3NzIn0= */");

/***/ })

}]);
//# sourceMappingURL=279-es2015.js.map