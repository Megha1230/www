(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[312], {
    /***/
    "4bBv":
    /*!***************************************************************!*\
      !*** ./src/app/pages/ownership-list/ownership-list.page.scss ***!
      \***************************************************************/

    /*! exports provided: default */

    /***/
    function bBv(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJvd25lcnNoaXAtbGlzdC5wYWdlLnNjc3MifQ== */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=312-es5.js.map