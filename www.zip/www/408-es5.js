(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[408], {
    /***/
    "p9Us":
    /*!*******************************************!*\
      !*** ./src/app/pages/home/home.page.html ***!
      \*******************************************/

    /*! no static exports found */

    /***/
    function p9Us(module, exports) {
      throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-landing-main *ngIf=\"commonProv.isMobileLayout() && refreshFlag\">\n| </ps-template-landing-main>\n| <ng-container *ngIf=\"(commonProv.isWebLayout() || landingType==4) && videoUrl\">");
      /***/
    }
  }]);
})();