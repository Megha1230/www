(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[445], {
    /***/
    "R9dr":
    /*!*********************************************************!*\
      !*** ./src/app/pages/pos-request/pos-request.page.html ***!
      \*********************************************************/

    /*! no static exports found */

    /***/
    function R9dr(module, exports) {
      throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-stepper [options]=\"stepperOptions\" [id]=\"stepperOptions.stepperName\">\n|   <ps-form-step *psStep=\"'step1'\" step1 [id]=\"stepperOptions.namesofSteps[0]\">\n|     <ps-container-panel [options]=\"mainDetailsOptions\" id=\"main_details_panel\">");
      /***/
    }
  }]);
})();