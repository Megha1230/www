(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[257], {
    /***/
    "Xaki":
    /*!*****************************************************************!*\
      !*** ./src/app/pages/account-opening/account-opening.page.scss ***!
      \*****************************************************************/

    /*! exports provided: default */

    /***/
    function Xaki(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhY2NvdW50LW9wZW5pbmcucGFnZS5zY3NzIn0= */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=257-es5.js.map