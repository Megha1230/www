(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[350],{

/***/ "9p9G":
/*!*************************************************************!*\
  !*** ./src/app/pages/accounts-list/accounts-list.page.html ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-view [options]=\"templateViewOptions\">\n| \n|   <ps-complex-segment id=\"accountsSegment\" (complexSegmentButtonClicked)=\"onClickSegment($event)\"");

/***/ })

}]);
//# sourceMappingURL=350-es2015.js.map