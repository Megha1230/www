(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[255], {
    /***/
    "66TZ":
    /*!*******************************************************************!*\
      !*** ./src/app/pages/account-deletion/account-deletion.page.scss ***!
      \*******************************************************************/

    /*! exports provided: default */

    /***/
    function TZ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhY2NvdW50LWRlbGV0aW9uLnBhZ2Uuc2NzcyJ9 */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=255-es5.js.map