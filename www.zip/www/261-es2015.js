(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[261],{

/***/ "+gGU":
/*!*********************************************************************************!*\
  !*** ./src/app/pages/activate-soft-token-otp/activate-soft-token-otp.page.scss ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhY3RpdmF0ZS1zb2Z0LXRva2VuLW90cC5wYWdlLnNjc3MifQ== */");

/***/ })

}]);
//# sourceMappingURL=261-es2015.js.map