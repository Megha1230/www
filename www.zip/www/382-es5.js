(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[382], {
    /***/
    "dQ7s":
    /*!*****************************************************************!*\
      !*** ./src/app/pages/cif-list-report/cif-list-report.page.html ***!
      \*****************************************************************/

    /*! no static exports found */

    /***/
    function dQ7s(module, exports) {
      throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-view [options]=\"templateViewOptions\">\n|     <ng-container *ngIf=\"!requestWasSent\">\n|         <ps-cif-list [options]=\"cifReportListOptions\" (reloadFct)=\"loadCifOpeningList()\"></ps-cif-list>");
      /***/
    }
  }]);
})();