(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[429],{

/***/ "AWho":
/*!*******************************************************!*\
  !*** ./src/app/pages/omni-login/omni-login.page.html ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ion-content class=\"login-page\">\n| \t<div class=\"container-fluid ion-no-padding\">\n| \t\t<div class=\"row ion-no-padding\">");

/***/ })

}]);
//# sourceMappingURL=429-es2015.js.map