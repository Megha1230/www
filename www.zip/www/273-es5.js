(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[273], {
    /***/
    "+FaT":
    /*!***************************************************************************************!*\
      !*** ./src/app/pages/cash-and-cheque-collection/cash-and-cheque-collection.page.scss ***!
      \***************************************************************************************/

    /*! exports provided: default */

    /***/
    function FaT(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjYXNoLWFuZC1jaGVxdWUtY29sbGVjdGlvbi5wYWdlLnNjc3MifQ== */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=273-es5.js.map