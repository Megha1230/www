(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[334], {
    /***/
    "2V5f":
    /*!***************************************************************************************!*\
      !*** ./src/app/pages/supplementary-card-request/supplementary-card-request.page.scss ***!
      \***************************************************************************************/

    /*! exports provided: default */

    /***/
    function V5f(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzdXBwbGVtZW50YXJ5LWNhcmQtcmVxdWVzdC5wYWdlLnNjc3MifQ== */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=334-es5.js.map