(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[465], {
    /***/
    "HCF6":
    /*!***********************************************************************************!*\
      !*** ./src/app/pages/scheduled-transfers-list/scheduled-transfers-list.page.html ***!
      \***********************************************************************************/

    /*! no static exports found */

    /***/
    function HCF6(module, exports) {
      throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-view [options]=\"templateViewOptions\">\n|    <ng-container *ngIf=\"!requestWasSent\">\n|          <ps-scheduled-transfers-list [options]=\"sheduledTransferListOptions\" (reloadFct)=\"loadScheduledTransfers()\">");
      /***/
    }
  }]);
})();