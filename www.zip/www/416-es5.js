(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[416], {
    /***/
    "XIGt":
    /*!*****************************************************************************!*\
      !*** ./src/app/pages/landing-customization/landing-customization.page.html ***!
      \*****************************************************************************/

    /*! no static exports found */

    /***/
    function XIGt(module, exports) {
      throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-landing-web></ps-template-landing-web>");
      /***/
    }
  }]);
})();