(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([[359], {
    /***/
    "8vmJ":
    /*!***********************************************************************************!*\
      !*** ./src/app/pages/bank-verification-number/bank-verification-number.page.html ***!
      \***********************************************************************************/

    /*! no static exports found */

    /***/
    function vmJ(module, exports) {
      throw new Error("Module parse failed: Unexpected token (1:0)\nYou may need an appropriate loader to handle this file type, currently no loaders are configured to process this file. See https://webpack.js.org/concepts#loaders\n> <ps-template-form [options]=\"options\">\n|   <ps-container-panel [options]=\"bvnPanelOptions\">\n|     <ps-keyin-input [options]=\"bvnInputOptions\" class=\"bvn_field_value\"></ps-keyin-input>");
      /***/
    }
  }]);
})();